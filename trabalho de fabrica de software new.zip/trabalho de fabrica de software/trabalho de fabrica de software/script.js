let tarefas = carregarTarefas();

function carregarTarefas() {
  const dados = localStorage.getItem("tarefas");
  return dados ? JSON.parse(dados) : [];
}

function salvarTarefas() {
  localStorage.setItem("tarefas", JSON.stringify(tarefas));
}

function adicionarTarefa() {
  const titulo = document.getElementById("titulo").value.trim();
  const data = document.getElementById("data").value; 
  const descricao = document.getElementById("descricao").value.trim();

  if (!titulo || !data) {
    alert("Preencha título e data da tarefa");
    return;
  }

  const tarefa = {
    id: Date.now(),
    titulo: titulo || "",
    data: data || "",
    descricao: descricao || "",
    concluida: false
  };

  tarefas.push(tarefa);

  salvarTarefas();
  renderizar();

  document.getElementById("titulo").value = "";
  document.getElementById("data").value = "";
  document.getElementById("descricao").value = "";
}

function toggleConclusao(id) {
  tarefas = tarefas.map(t =>
    t.id === id ? { ...t, concluida: !t.concluida } : t
  );

  salvarTarefas();
  renderizar();
}

function formatarDataBR(dataISO) {
  if (!dataISO) return "";
  const [ano, mes, dia] = dataISO.split("-");
  return `${dia}/${mes}/${ano}`;
}

function agruparPorData(lista) {
  const grupos = {};

  lista.forEach(t => {
    if (!grupos[t.data]) {
      grupos[t.data] = [];
    }
    grupos[t.data].push(t);
  });

  Object.keys(grupos).forEach(data => {
    grupos[data].sort((a, b) => b.id - a.id);
  });

  return grupos;
}

function renderizar() {
  const container = document.getElementById("lista");
  container.innerHTML = "";

  if (tarefas.length === 0) {
    container.innerHTML = `<p class="empty">Nenhuma tarefa cadastrada.</p>`;
    return;
  }

  const grupos = agruparPorData(tarefas);

  const datasOrdenadas = Object.keys(grupos).sort((a, b) => {
    return new Date(b) - new Date(a);
  });

  datasOrdenadas.forEach(data => {
    const grupoDiv = document.createElement("div");
    grupoDiv.className = "data-group";

    grupoDiv.innerHTML = `
      <div class="data-titulo">
        ${formatarDataBR(data)}
      </div>
    `;

    grupos[data].forEach(t => {
      const task = document.createElement("div");
      task.className = "task";

      task.innerHTML = `
        <div class="task-info">
          <div class="task-title ${t.concluida ? "concluida" : ""}">
            ${t.titulo || ""}
          </div>
          <div class="task-desc">
            ${t.descricao || ""}
          </div>
        </div>

        <input type="checkbox"
          ${t.concluida ? "checked" : ""}
          onclick="toggleConclusao(${t.id})">
      `;

      grupoDiv.appendChild(task);
    });

    container.appendChild(grupoDiv);
  });
}

renderizar();